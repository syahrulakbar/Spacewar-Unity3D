using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{

    public GameObject InfoPanel;
    public GameObject MenuPanel;

    private void Start()
    {
        InfoPanel.SetActive(false);
        MenuPanel.SetActive(true);
    }
    public void Play()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void Quit()
    {
        Application.Quit();
        Debug.Log("Player Has Quit The Game");
    }

    public void InfoButton()
    {
        InfoPanel.SetActive(true);
        MenuPanel.SetActive(false);

    }

    public void CloseButton()
    {
        InfoPanel.SetActive(false);
        MenuPanel.SetActive(true);

    }
}
